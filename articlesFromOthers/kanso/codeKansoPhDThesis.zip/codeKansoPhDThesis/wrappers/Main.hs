module Main where

import Codec.TPTP.Import
import Codec.TPTP.Pretty
import Codec.TPTP.Base
--import Data.Functor.Identity -- works at on laptop
import Control.Monad.Identity -- works at uni (ghc 6.12.1)
import qualified Data.Map as Map
import Data.Maybe
import qualified Data.List as List
import qualified System.Directory as Dir
import System.IO
import System.Process
import System.Exit
import Data.Generics
import System
import FOLFormula
import Data.Binary
import qualified Data.ByteString.Lazy as B

step1 :: [TPTP_Input] -> [Record]
step1 = (map input2record) . (filter filt_AFormula)

input2record x = (input2id x , (input2formula x , input2rule x))

-- should tidy up temp file
inputfile :: IO String
inputfile = do
  args <- getArgs
  case List.find (\ s -> not $ List.isPrefixOf "--" s) args of
    Nothing -> do
              tmpdir <- Dir.getTemporaryDirectory
              (tmpfile , htmp) <- openTempFile tmpdir "eproof-input"
              hGetContents stdin >>= hPutStr htmp -- problem -- will be changed to copy from stdin untill eof
              hFlush htmp
              hClose htmp
              return tmpfile
    Just s -> return s


main :: IO ()
main = do
  args <- getArgs
  tmpfile <- inputfile
  let
      atp_cp :: CreateProcess
      atp_cp = CreateProcess (RawCommand ("eproof") ["--tstp-format",tmpfile]) 
                             Nothing Nothing 
                             Inherit CreatePipe Inherit
                             True
  (inp,Just out,err,pid) <- createProcess atp_cp
--  putStrLn tmpfile
-- ##  exitcode <- waitForProcess pid
--  putStrLn "kipper"
-- ##  Dir.removeFile tmpfile
  rawlines <- fmap parse $ hGetContents out
--  putStrLn rawoutput
--  let rawlines = parse rawoutput
 
  if (Comment "# SZS status Unsatisfiable") `elem` rawlines then
      do
--        let x = step1 rawlines
        if "--quiet" `elem` args then
            putStrLn "Problem set provable, proof object hidden in quiet mode."                     
        else do 
--          let t = dischargetree $ buildtree (buildvarmap (getvars' x) (getstrings' x)) (snd $ fromJust $ getroot x) x 
          if "--ascii" `elem` args then
              if "--agda" `elem` args then
                  if "--list" `elem` args then
                      putStrLn $ showAgda $ constructList $ step1 rawlines
                  else
                      putStrLn $ showAgda $ constructTree $ step1 rawlines
              else
                  if "--list" `elem` args then
                      putStrLn $ show $ constructList $ step1 rawlines
                  else
                      putStrLn $ show $ constructTree $ step1 rawlines
          else  {-# SCC "myoutput" #-} 
              B.hPut stdout ( {-# SCC "myencoded" #-} encode ( {-# SCC "mytree" #-} Just $ constructTree $ step1 rawlines))
  else 
      do
        if "--ascii" `elem` args then
            putStrLn "Problem set un-provable."                     
        else
            B.hPut stdout $ encode (Nothing :: Maybe (ProofTree (Proves FOLFormula FOLFormula)))
        hClose out
        exitFailure
  hClose out

constructTree :: [Record] -> ProofTree (Proves FOLFormula FOLFormula)
constructTree lines = dischargetree $ snd $ head $ buildtrees (buildvarmap (getvars' lines) (getstrings' lines)) [] lines

constructList :: [Record] -> [PNode]
constructList lines = dischargelist $ buildnodes [] lines (buildvarmap (getvars' lines) (getstrings' lines)) (Map.empty) []

-- main2 :: IO ()
-- main2 = do
--   let
--       atp_cp :: CreateProcess
--       atp_cp = CreateProcess (RawCommand ("eproof") ["--tstp-format","/home/kazza/prooftree/eppinitial.tstp"]) 
--                              Nothing Nothing 
--                              Inherit CreatePipe Inherit
--                              True
--   (inp,Just out,err,pid) <- createProcess atp_cp
-- --  putStrLn tmpfile
-- -- ##  exitcode <- waitForProcess pid
--   putStrLn "kipper"
-- -- ##  Dir.removeFile tmpfile
--   rawoutput <- hGetContents out
-- --  putStrLn rawoutput
--   let rawlines = parse rawoutput
 
--   if (Comment "# SZS status Unsatisfiable") `elem` rawlines then
--       do
--         let x = step1 rawlines
--         putStrLn $ show $ dischargetree $ buildtree (buildvarmap (getvars' x) (getstrings' x)) (snd $ fromJust $ getroot x) x 
--   else 
--       do
--         hClose out
--         exitFailure
--   hClose out

-- data Pseudo_Formula = 
--   PseudoTrue | PseudoFalse | PseudoOr Pseudo_Formula Pseudo_Formula |
--   PseudoAnd Pseudo_Formula Pseudo_Formula | PseudoImp Pseudo_Formula Pseudo_Formula |
--   PseudoVar Integer | PseudoNeg Pseudo_Formula | PseudoFun Integer [ Pseudo_Formula ] |
--   PseudoAll Integer Pseudo_Formula | PseudoExist Integer Pseudo_Formula
--                deriving (Show,Eq,Read)

data PL_FormulaCode = 
  True_ | False_ | Or_ PL_FormulaCode PL_FormulaCode |
  And_ PL_FormulaCode PL_FormulaCode | Imp_ PL_FormulaCode PL_FormulaCode |
  Var_ (Either String Int) | Neg_ PL_FormulaCode
  deriving (Show,Eq)

-- data Proves f f' =
-- --  (:-) {gamma :: [f] , phi :: f'}
--   Proves [f] f' --{gamma :: [f] , phi :: f'}
--   deriving (Show,Eq)

gamma :: Proves f f' -> [f]
gamma (Proves a b) = a

phi :: Proves f f' -> f'
phi (Proves a b) = b

--instance (Show f , Show f') => Show (Proves f f') where
--    show p = concat [ "Proves " , (show $ gamma p) , " " , (show $ phi p) ]

-- data ProofTree f = 
-- --  ProofNode {rule :: String , conc :: f , seq' :: [ ProofTree f ] }
--   ProofNode String f [ ProofTree f ]
--   deriving (Show,Eq)

conc :: ProofTree f -> f
conc (ProofNode a b c) = b

--instance Show f => Show (ProofTree f) where
--    show node = concat [ "(Node \"" , rule node , "\" " , (show $ conc node) , " " , (show $ seq' node) , ")" ]

data ERuleCode =
  NNF_ Int | Simplify_ Int  | SplitConj_ Int | CN_ Int | Axiom_ | UnSat_ Int | Distribute_ Int |
  Apply_ Int [Int] | RW_ Int Int | Void_ Int | SR_ Int Int | PM_ Int Int

instance Show ERuleCode where
    show (NNF_ _) = "fof_nnf"
    show (Simplify_ _) = "fof_simplification"  
    show (SplitConj_ _) = "split_conjunct"
    show (CN_ _) = "cn"
    show Axiom_ = "axiom"
    show (UnSat_ _) = "unsat"
    show (Distribute_ _) = "distribute"
    show (Apply_ _ _) = "apply_def"
    show (RW_ _ _) = "rw"
    show (Void_ _) = "#ERROR#"
    show (SR_ _ _) = "sr"
    show (PM_ _ _) = "pm"


binop2formula :: BinOp -> PL_FormulaCode -> PL_FormulaCode -> PL_FormulaCode
binop2formula (:<=>:) a b = And_ (Imp_ a b) (Imp_ b a)
binop2formula (:=>:) a b = Imp_ a b
binop2formula (:<=:) a b = Imp_ b a
binop2formula (:&:) a b = And_ a b
binop2formula (:|:) a b = Or_ a b
-- possibly these make inconsistencies
binop2formula (:~&:) a b = Neg_ (And_ a b)
binop2formula (:~|:) a b = Neg_ (Or_ a b)
binop2formula (:<~>:) a b = And_ (Or_ a b) (Or_ (Neg_ a) (Neg_ b))

readatom :: String -> Either String Int
readatom s = case ((reads :: ReadS Int) s) of 
  [(n,[])] -> Right n 
  _ -> Left s

atom2formula :: AtomicWord -> PL_FormulaCode
atom2formula (AtomicWord atom) | atom == "$true" = True_
                               | atom == "$false" = False_
                               | otherwise = Var_ $ readatom atom

formula02formula :: Formula0 (T Identity) (F Identity) -> PL_FormulaCode
formula02formula (BinOp a op b) = binop2formula op (formula2formula a) (formula2formula b)
formula02formula (InfixPred t1 ip t2) = undefined -- not used
formula02formula (PredApp atom []) = atom2formula atom -- all veriables and constants are here
formula02formula (PredApp atom ts) = undefined -- predicates not used
formula02formula (Quant q vs f) = undefined -- should not happen, only propositional formulae
formula02formula ((:~:) a) = let a' = (formula2formula a)
                             in case a' of 
                                  True_ -> False_
                                  False_ -> True_
                                  _ -> Neg_ a'

formula2formula :: F Identity -> PL_FormulaCode
formula2formula = formula02formula . runIdentity . runF


input2formula :: TPTP_Input -> PL_FormulaCode
input2formula = formula2formula . formula
{-
  NNF | Simplify | SplitConj | CN | Axiom | UnSat | Distribute |
  Apply f f | RW f | Fresh Int f
-}

-- tonum :: GTerm -> Int
-- tonum x@(GTerm (GNumber n)) = tonum' x
-- tonum x = tonum' x

-- tonum' :: GTerm -> Int
-- tonum' (GTerm (GNumber n)) = floor n
-- tonum' x = undefined

tonum :: GTerm -> Int
tonum (GTerm (GNumber n)) = floor n
tonum x = undefined

applydef2rule :: [GTerm] -> [Int]
applydef2rule = map floor . listify ((\ x -> True) :: Double -> Bool)

inference2rule :: [GTerm] -> ERuleCode
inference2rule [GTerm (GWord (AtomicWord a)) , _ , GList b] | a == "fof_nnf" = NNF_ (tonum (head b))
                                                            | a == "fof_simplification" = Simplify_ (tonum (head b))
                                                            | a == "split_equiv" = SplitConj_ (tonum (head b))
                                                            | a == "split_conjunct" = SplitConj_ (tonum (head b))
                                                            | a == "cn" = CN_ (tonum (head b))
                                                            | a == "distribute" = Distribute_ (tonum (head b))
                                                                                  --        \/\/\/ this could be repeated applications of apply_def
--                                                            | a == "apply_def" = Apply_ (tonum (head b)) [(tonum (head (tail b)))]
                                                            | a == "apply_def" = let indices = applydef2rule b
                                                                                 in Apply_ (head indices) $ tail indices
--                                                            | a == "apply_def" = Apply_ 1 (tonum (head (tail b)))
                                                            | a == "rw" = RW_ (tonum (head b)) (tonum (head (tail b)))
                                                            | a == "eval_answer_literal" = Void_ (tonum (head b))
                                                            | a == "sr" = SR_ (tonum (head b)) (tonum (head (tail b)))
                                                            | a == "pm" = PM_ (tonum (head b)) (tonum (head (tail b)))
inference2rule _ = undefined
-- apply's first argument can be nested apply_def's

annotation2rule :: Annotations -> ERuleCode
annotation2rule NoAnnotations = undefined
annotation2rule (Annotations (GTerm (GApp (AtomicWord n) args)) NoUsefulInfo) | n == "introduced" = Axiom_
                                                                              | n == "inference" = inference2rule args
                                                                              | n == "file" = Axiom_
annotation2rule (Annotations (GTerm (GNumber n)) (UsefulInfo [(GTerm (GWord (AtomicWord m)))])) | m == "proof" = UnSat_ (floor n)
annotation2rule (Annotations gt _) = undefined


input2rule :: TPTP_Input -> ERuleCode
input2rule = annotation2rule . annotations

input2id :: TPTP_Input -> Int
input2id = (\ (AtomicWord x) -> read x) . name

filt_AFormula :: TPTP_Input -> Bool
filt_AFormula (AFormula _ _ _ _) = Prelude.True
filt_AFormula _ = Prelude.False

filt_Comment :: TPTP_Input -> Bool
filt_Comment (Comment _) = Prelude.True
filt_Comment _ = Prelude.False

type Record = (Int , (PL_FormulaCode,ERuleCode))
type Record2 = (Int , (FOLFormula,ERuleCode))

data PNode = N  {rule :: String , pnodeform :: (Proves FOLFormula FOLFormula) , seq :: [Int]}
             deriving (Show)

instance ShowAgda Int where showAgda = show

instance ShowAgda PNode where
    showAgda (N s f i) = "(node " ++ s ++ " " ++ showAgda f ++ " " ++ showAgda i ++ ")" 

-- pnodeform :: PNode -> Proves FOLFormula FOLFormula
-- pnodeform (N _ c _) = c

next :: [Int] -> Int
next xs = f xs 0
  where 
    f :: [Int] -> Int -> Int
    f xs n | n `elem` xs = f xs (n + 1)
           | otherwise = n
                         
getvars :: PL_FormulaCode -> [Int]
getvars True_ = []
getvars False_ = []
getvars (Or_ a b) = getvars a ++ getvars b
getvars (And_ a b) = getvars a ++ getvars b
getvars (Imp_ a b) = getvars a ++ getvars b
getvars (Var_ x) = either (\ _ -> []) (:[]) x
getvars (Neg_ a) = getvars a

getvars' :: [Record] -> [Int]
getvars' = foldr (\ (_ , (formula , rule)) b -> getvars formula ++ b) []


getstrings :: PL_FormulaCode -> [String]
getstrings True_ = []
getstrings False_ = []
getstrings (Or_ a b) = getstrings a ++ getstrings b
getstrings (And_ a b) = getstrings a ++ getstrings b
getstrings (Imp_ a b) = getstrings a ++ getstrings b
getstrings (Var_ x) = either (:[]) (\ _ -> []) x
getstrings (Neg_ a) = getstrings a

getstrings' :: [Record] -> [String]
getstrings' = foldr (\ (_ , (formula , rule)) b -> getstrings formula ++ b) []

buildvarmap :: [Int] -> [String] -> [(String , Int)]
buildvarmap ids [] = []
buildvarmap ids (s : strs) | s `elem` strs = buildvarmap ids strs
                           | otherwise     = let n = Main.next ids
                                             in (s , n) : buildvarmap (n : ids) strs


buildvarmap' :: [Int] -> [String] -> Map.Map String Int
buildvarmap' ids strs = Map.fromList $ buildvarmap ids strs

toformula :: Map.Map String Int -> PL_FormulaCode -> FOLFormula
toformula env True_ = FOLTrue
toformula env False_ = FOLFalse
toformula env (Or_ a b) = FOLOr (toformula env a) (toformula env b)
toformula env (And_ a b) = FOLAnd (toformula env a) (toformula env b)
toformula env (Imp_ a b) = FOLImp (toformula env a) (toformula env b)
-- lookup should never fail assuming the environment has been correctly 
-- constructed, i.e. total w.r.t. strings occuring in the formula (fromJust
toformula env (Var_ x) = FOLVar $ fromIntegral $ either (\ s ->  maybe (-1) id $ Map.lookup s env) (id) x
toformula env (Neg_ a) = FOLNeg $ toformula env a

toformula' :: [(String,Int)] -> PL_FormulaCode -> FOLFormula
toformula' env True_ = FOLTrue
toformula' env False_ = FOLFalse
toformula' env (Or_ a b) = FOLOr (toformula' env a) (toformula' env b)
toformula' env (And_ a b) = FOLAnd (toformula' env a) (toformula' env b)
toformula' env (Imp_ a b) = FOLImp (toformula' env a) (toformula' env b)
-- lookup should never fail assuming the environment has been correctly 
-- constructed, i.e. total w.r.t. strings occuring in the formula (fromJust?)
toformula' env (Var_ x) = FOLVar $ fromIntegral $ either (\ s ->  maybe (-1) id $ lookup s env) (id) x
toformula' env (Neg_ a) = FOLNeg $ toformula' env a

-- toformula'' :: PL_FormulaCode -> FOLFormula
-- toformula'' True_ = FOLTrue
-- toformula'' False_ = FOLFalse
-- toformula'' (Or_ a b) = FOLOr (toformula'' a) (toformula'' b)
-- toformula'' (And_ a b) = FOLAnd (toformula'' a) (toformula'' b)
-- toformula'' (Imp_ a b) = FOLImp (toformula''  a) (toformula'' b)
-- toformula'' (Var_ x) = FOLVar $ fromIntegral $ either (\ s ->  0) (id) x
-- toformula'' (Neg_ a) = FOLNeg $ toformula'' a

getroot :: [(Int,b)] -> Maybe (Int,b) --(PL-Formula,ERuleCode)
getroot xs = foldr (\ a b -> if (fst a > maybe (-1) fst b) then Just a else b) Nothing  xs

splitand :: FOLFormula -> FOLFormula
splitand (FOLAnd f1 f2) = f1
splitand x = x

splitand' :: FOLFormula -> FOLFormula
splitand' (FOLAnd f1 f2) = f2
splitand' x = x

splitimp :: FOLFormula -> FOLFormula
splitimp (FOLImp f1 f2) = f1
splitimp x = x

splitimp' :: FOLFormula -> FOLFormula
splitimp' (FOLImp f1 f2) = f2
splitimp' x = x

subformula :: FOLFormula -> FOLFormula -> Bool
subformula x y | x == y = True
subformula x FOLTrue = False
subformula x FOLFalse = False
subformula x (FOLOr a b) = subformula x a || subformula x b
subformula x (FOLAnd a b) = subformula x a || subformula x b
subformula x (FOLImp a b) =  subformula x a || subformula x b
subformula x (FOLVar n) = False
subformula x (FOLNeg a) = subformula x a


unnegate :: FOLFormula -> FOLFormula
unnegate (FOLNeg a) = a
unnegate (FOLImp a FOLFalse) = a
unnegate (FOLImp a (FOLImp FOLTrue FOLFalse)) = a
unnegate a = a

-- buildtree = buildtree'

-- -- map from strings to variable indices, root node, records => tree
-- buildtree' :: [(String,Int)] -> (PL_FormulaCode,ERuleCode) -> [Record] -> ProofTree (Proves FOLFormula FOLFormula)
-- buildtree' env (f , NNF_ n) m = let r = buildtree' env (fromJust $ lookup n m) m
--                                 in ProofNode "fof_nnf" (Proves (gamma $ conc r) $ toformula' env f) [ r ]
-- buildtree' env (f , Simplify_ n) m = let r = buildtree' env (fromJust $ lookup n m) m
--                                      in ProofNode "fof_simplification" (Proves (gamma $ conc r) $ toformula' env f) [ r ]
-- buildtree' env (f , SplitConj_ n) m = let r = buildtree' env (fromJust $ lookup n m) m
--                                       in ProofNode "split_conjunct" (Proves (gamma $ conc r) $ toformula' env f) [ r ]
-- buildtree' env (f , CN_ n) m = let r = buildtree' env (fromJust $ lookup n m) m
--                                in ProofNode "cn" (Proves (gamma $ conc r) $ toformula' env f) [ r ]
-- buildtree' env (f , Axiom_) m = ProofNode "axiom" (Proves [toformula' env f] $ toformula' env f) []
-- buildtree' env (f , UnSat_ n) m = let f1 = phi $ conc $ buildtree' env (fromJust $ lookup 1 m) m -- axiom from file, should always be negated
--                                       r = buildtree' env (fromJust $ lookup n m) m
-- --             might need to change equality here to equivalence       \/\/
--                                   in ProofNode "unsat" (Proves (filter (\ a -> not $ f1 == a) (gamma $ conc r)) $ unnegate f1) [ r ]
-- buildtree' env (f , Distribute_ n) m = let r = buildtree' env (fromJust $ lookup n m) m
--                                        in ProofNode "distribute" (Proves (gamma $ conc r) $ toformula' env f) [ r ]


-- buildtree' env (f , Apply_ n1 n2) m = let r1 = buildtree' env (fromJust $ lookup n1 m) m -- n2 is a list of definitions that n1 is applied to
--                                           r2s = map (\ n -> buildtree' env (fromJust $ lookup n m) m) n2 --- #################### WARNINGNGNGNGNGN
-- --                                          g = phi $ conc r2
--                                       in buildapply r1 r2s
-- -- ProofNode "apply_def" (Proves (List.nub ((gamma $ conc r1) ++ (gamma $ conc r2))) $ toformula' env f) [ r1 , r2 ]


-- buildtree' env (f , RW_ n1 n2) m = let r1 = buildtree' env (fromJust $ lookup n1 m) m
--                                        r2 = buildtree' env (fromJust $ lookup n2 m) m
--                                        f' = if (FOLNeg (phi $ conc r2) `subformula` (phi $ conc r1)) then phi $ conc r2
--                                             else unnegate $ phi $ conc r2
--                                    in ProofNode "rw" (Proves (List.nub ((gamma $ conc r1) ++ (gamma $ conc r2))) $ toformula' env f) [ r1 , r2 ]
-- buildtree' env (f , Void_ n) m = buildtree' env (fromJust $ lookup n m) m
-- buildtree' env (f , SR_ n1 n2) m = let r1 = buildtree' env (fromJust $ lookup n1 m) m
--                                        r2 = buildtree' env (fromJust $ lookup n2 m) m
--                                        f' = if (FOLNeg (phi $ conc r2) `subformula` (phi $ conc r1)) then phi $ conc r2
--                                             else unnegate $ phi $ conc r2
--                                    in ProofNode "sr" (Proves (List.nub ((gamma $ conc r1) ++ (gamma $ conc r2))) $ toformula' env f) [ r1 , r2 ]
-- buildtree' env (f , PM_ n1 n2) m = let r1 = buildtree' env (fromJust $ lookup n1 m) m
--                                        r2 = buildtree' env (fromJust $ lookup n2 m) m
--                                        f' = if (FOLNeg (phi $ conc r2) `subformula` (phi $ conc r1)) then phi $ conc r2
--                                             else unnegate $ phi $ conc r2
--                                    in ProofNode "pm" (Proves (List.nub ((gamma $ conc r1) ++ (gamma $ conc r2))) $ toformula' env f) [ r1 , r2 ]

buildnode :: [PNode] -> [(String,Int)] -> Map.Map Int Int -> PL_FormulaCode -> ERuleCode -> [PNode]
buildnode done env m f (NNF_ n)        = let a = fromJust (Map.lookup n m)
                                         in [N "fof_nnf" (Proves (gamma $ pnodeform $ done !! a) $ toformula' env f) [a]]
buildnode done env m f (Simplify_ n)   = let a = fromJust (Map.lookup n m)
                                         in [N "fof_simplification" (Proves (gamma $ pnodeform $ done !! a) $ toformula' env f) [a]]
buildnode done env m f (SplitConj_ n)  = let a = fromJust (Map.lookup n m)
                                         in [N "split_conjunct" (Proves (gamma $ pnodeform $ done !! a) $ toformula' env f) [a]]
buildnode done env m f (CN_ n)         = let a = fromJust (Map.lookup n m)
                                         in [N "cn" (Proves (gamma $ pnodeform $ done !! a) $ toformula' env f) [a]]
buildnode done env m f Axiom_          = [N "axiom" (Proves [toformula' env f] $ toformula' env f) []]
buildnode done env m f (UnSat_ n)      = let f1 = phi $ pnodeform $ head done
                                         in [N "unsat" (Proves (filter (\ a -> not $ f1 == a) (gamma $ pnodeform $ done !! fromJust (Map.lookup n m))) $ unnegate f1) [fromJust (Map.lookup n m)]]
buildnode done env m f (Distribute_ n) = let a = fromJust (Map.lookup n m)
                                         in [N "distribute" (Proves (gamma $ pnodeform $ done !! a) $ toformula' env f) [a]]
buildnode done env m f (Apply_ n n')   = buildapplynode done (fromJust $ Map.lookup n m) (map (\ x -> fromJust $ Map.lookup x m) n')
buildnode done env m f (RW_ n n')      = let a = fromJust $ Map.lookup n m
                                             b = fromJust $ Map.lookup n' m
                                         in [N "rw" (Proves (List.nub ((gamma $ pnodeform $ done !! a) ++ (gamma $ pnodeform $ done !! b))) $ toformula' env f) [a,b]]
buildnode done env m f (Void_ n)       = [done !! fromJust (Map.lookup n m)]
buildnode done env m f (SR_ n n')      = let a = fromJust $ Map.lookup n m
                                             b = fromJust $ Map.lookup n' m
                                         in [N "sr" (Proves (List.nub ((gamma $ pnodeform $ done !! a) ++ (gamma $ pnodeform $ done !! b))) $ toformula' env f) [a,b]]
buildnode done env m f (PM_ n n')      = let a = fromJust $ Map.lookup n m
                                             b = fromJust $ Map.lookup n' m
                                         in [N "pm" (Proves (List.nub ((gamma $ pnodeform $ done !! a) ++ (gamma $ pnodeform $ done !! b))) $ toformula' env f) [a,b]]

buildapplynode :: [PNode] 
               -> Int
               -> [Int]
               -> [PNode]
buildapplynode done f [def] | isEquiv $ phi $ pnodeform $ done !! def = 
  let f' = pnodeform $ done !! f
      eqv = pnodeform $ done !! def
  in [N "apply_def" (Proves (List.nub ((gamma f') ++ (gamma eqv))) $ subst (phi f') (equivLeft $ phi eqv) (equivRight $ phi eqv)) [ f , def ]]
--                                     \/ nub is a performance issue
buildapplynode done f (def : defs) | isEquiv $ phi $ pnodeform $ done !! def = 
  let f' = buildapplynode done f defs
      eqv = pnodeform $ done !! def
  in f' ++ [N "apply_def" (Proves (List.nub ((gamma $ pnodeform $ last f') ++ (gamma eqv))) $ subst (phi $ pnodeform $ last f') (equivLeft $ phi eqv) (equivRight $ phi eqv)) [ length (done ++ f') -1 , def ]]


buildnodes :: [Record] -> [Record] -> [(String,Int)] -> Map.Map Int Int -> [PNode] -> [PNode]
buildnodes r1 [] env m a = a
buildnodes r1 (n@(i, (f , r)) : r2) env m a = buildnodes (r1 ++ [n]) r2 env (Map.insert i (length r1) m) (a ++ buildnode a env m f r)


buildtree'' :: [(String,Int)] -> [(Int,ProofTree (Proves FOLFormula FOLFormula))] -> PL_FormulaCode -> ERuleCode -> ProofTree (Proves FOLFormula FOLFormula)

buildtree'' env processed formula (NNF_ n) = let r = fromJust $ lookup n processed
                                             in ProofNode "fof_nnf" (Proves (gamma $ conc r) $ toformula' env formula) [ r ]
buildtree'' env processed formula (Simplify_ n) = let r = fromJust $ lookup n processed
                                                  in ProofNode "fof_simplification" (Proves (gamma $ conc r) $ toformula' env formula) [ r ]
buildtree'' env processed formula (SplitConj_ n) = let r = fromJust $ lookup n processed
                                                   in ProofNode "split_conjunct" (Proves (gamma $ conc r) $ toformula' env formula) [ r ]
buildtree'' env processed formula (CN_ n) = let r = fromJust $ lookup n processed
                                            in ProofNode "cn" (Proves (gamma $ conc r) $ toformula' env formula) [ r ]
buildtree'' env processed formula Axiom_ = let f = toformula' env formula
                                           in ProofNode "axiom" (Proves [f] $ f) []
buildtree'' env processed formula (UnSat_ n) = let f1 = phi $ conc $ fromJust $ lookup 1 processed -- axiom from file, should always be negated
                                                   r = fromJust $ lookup n processed
                                               in ProofNode "unsat" (Proves (filter (\ a -> not $ f1 == a) (gamma $ conc r)) $ unnegate f1) [ r ]
buildtree'' env processed formula (Distribute_ n) = let r = fromJust $ lookup n processed
                                                    in ProofNode "distribute" (Proves (gamma $ conc r) $ toformula' env formula) [ r ]
buildtree'' env processed formula (Apply_ n1 n2) = let r1 = fromJust $ lookup n1 processed -- n2 is a list of definitions that n1 is applied to
                                                       r2s = map (\ n -> fromJust $ lookup n processed) n2
                                                   in buildapply r1 r2s
buildtree'' env processed formula (RW_ n1 n2) = let r1 = fromJust $ lookup n1 processed
                                                    r2 = fromJust $ lookup n2 processed
--                                                    f' = if (FOLNeg (phi $ conc r2) `subformula` (phi $ conc r1)) then phi $ conc r2
--                                                         else unnegate $ phi $ conc r2
                                                in ProofNode "rw" (Proves (List.nub ((gamma $ conc r1) ++ (gamma $ conc r2))) $ toformula' env formula) [ r1 , r2 ]
buildtree'' env processed formula (Void_ n) = fromJust $ lookup n processed
buildtree'' env processed formula (SR_ n1 n2) = let r1 = fromJust $ lookup n1 processed
                                                    r2 = fromJust $ lookup n2 processed
--                                                    f' = if (FOLNeg (phi $ conc r2) `subformula` (phi $ conc r1)) then phi $ conc r2
--                                                         else unnegate $ phi $ conc r2
                                                in ProofNode "sr" (Proves (List.nub ((gamma $ conc r1) ++ (gamma $ conc r2))) $ toformula' env formula) [ r1 , r2 ]
buildtree'' env processed formula (PM_ n1 n2) = let r1 = fromJust $ lookup n1 processed
                                                    r2 = fromJust $ lookup n2 processed
--                                                    f' = if (FOLNeg (phi $ conc r2) `subformula` (phi $ conc r1)) then phi $ conc r2
--                                                         else unnegate $ phi $ conc r2
                                                in ProofNode "pm" (Proves (List.nub ((gamma $ conc r1) ++ (gamma $ conc r2))) $ toformula' env formula) [ r1 , r2 ]

buildtrees :: [(String,Int)] -> [(Int,ProofTree (Proves FOLFormula FOLFormula))] -> [Record] -> [(Int,ProofTree (Proves FOLFormula FOLFormula))]
buildtrees env processed [] = processed
buildtrees env processed ((n,(f,r)) : unprocessed) = buildtrees env ((n,buildtree'' env processed f r) : processed) unprocessed


-- replace all occourances of psi1 in phi by psi2
subst :: FOLFormula -> FOLFormula -> FOLFormula -> FOLFormula
subst phi psi1 psi2 | phi == psi1 = psi2
subst FOLTrue psi1 psi2 = FOLTrue
subst FOLFalse psi1 psi2 = FOLFalse
subst (FOLOr a b) psi1 psi2 = FOLOr (subst a psi1 psi2) (subst b psi1 psi2)
subst (FOLAnd a b) psi1 psi2 = FOLAnd (subst a psi1 psi2) (subst b psi1 psi2)
subst (FOLImp a b) psi1 psi2 = FOLImp (subst a psi1 psi2) (subst b psi1 psi2)
subst (FOLVar n) psi1 psi2 = FOLVar n
subst (FOLNeg a) psi1 psi2 = FOLNeg (subst a psi1 psi2)
--subst (FOLFun n a) psi1 psi2 = FOLFun n a
subst (FOLAll n a) psi1 psi2 = FOLAll n (subst a psi1 psi2) 
subst (FOLExist n a) psi1 psi2 = FOLExist n (subst a psi1 psi2)
subst (FOLRel n a) psi1 psi2 = FOLRel n a

                                     

buildapply :: ProofTree (Proves FOLFormula FOLFormula)
           -> [ProofTree (Proves FOLFormula FOLFormula)]
           -> ProofTree (Proves FOLFormula FOLFormula)
buildapply f [def] | isEquiv $ phi $ conc def = ProofNode "apply_def" (Proves (List.nub ((gamma $ conc f) ++ (gamma $ conc def))) $ subst (phi $ conc f) (equivLeft $ phi $ conc def) (equivRight $ phi $ conc def) ) [ f , def ]
--                                                                                               \/ nub is a performance issue
buildapply f (def : defs) | isEquiv $ phi $ conc def = let f' = buildapply f defs
                                                       in ProofNode "apply_def" (Proves (List.nub ((gamma $ conc f') ++ (gamma $ conc def))) $ subst (phi $ conc f') (equivLeft $ phi $ conc def) (equivRight $ phi $ conc def) ) [ f' , def ]

isEquiv :: FOLFormula -> Bool
isEquiv (FOLAnd (FOLImp (FOLVar a) b) (FOLImp c (FOLVar d))) = a == d && b == c
isEquiv _ = False

equivLeft :: FOLFormula -> FOLFormula
equivLeft (FOLAnd (FOLImp a b) (FOLImp c d)) = a

equivRight :: FOLFormula -> FOLFormula
equivRight (FOLAnd (FOLImp a b) (FOLImp c d)) = b


dischargetree :: ProofTree (Proves FOLFormula FOLFormula) -> ProofTree (Proves FOLFormula FOLFormula)
dischargetree t | (gamma $ conc t) == [] = t
dischargetree t | isEquiv $ head $ gamma $ conc t = dischargetree $ ProofNode "fresh" (Proves (tail $ gamma $ conc t) $ phi $ conc t) [t]


dischargelist :: [PNode] -> [PNode]
dischargelist t | (gamma $ pnodeform $ last t) == [] = t
dischargelist t | isEquiv $ head $ gamma $ pnodeform $ last t = dischargelist $ (t ++ [N "fresh" (Proves (tail $ gamma $ pnodeform $ last t) $ phi $ pnodeform $ last t) [length t - 1]])

{-
file :: String
file = "# Preprocessing time       : 0.000 s\n# Problem is unsatisfiable (or provable), constructing proof object\n# SZS status Unsatisfiable\n# SZS output start CNFRefutation.\nfof(1, axiom,~(((((('5'=>'0')&('0'=>'5'))&((('4'=>'3')&('3'=>'4'))&(('6'=>('5'&'4'))&(('5'&'4')=>'6'))))&('a'&~('b')))=>~(('a'=>'b')))),file('sample.tptp', ax)).\nfof(2, plain,~(((((('5'=>'0')&('0'=>'5'))&((('4'=>'3')&('3'=>'4'))&(('6'=>('5'&'4'))&(('5'&'4')=>'6'))))&('a'&~('b')))=>~(('a'=>'b')))),inference(fof_simplification,[status(thm)],[1,theory(equality)])).\nfof(3, plain,(epred1_0<=>(((('5'=>'0')&('0'=>'5'))&((('4'=>'3')&('3'=>'4'))&(('6'=>('5'&'4'))&(('5'&'4')=>'6'))))&('a'&~('b')))),introduced(definition)).\nfof(4, plain,(epred1_0=>(((('5'=>'0')&('0'=>'5'))&((('4'=>'3')&('3'=>'4'))&(('6'=>('5'&'4'))&(('5'&'4')=>'6'))))&('a'&~('b')))),inference(split_equiv,[status(thm)],[3])).\nfof(5, plain,~((epred1_0=>~(('a'=>'b')))),inference(apply_def,[status(thm)],[2,3,theory(equality)])).\nfof(6, plain,(epred1_0&(~('a')|'b')),inference(fof_nnf,[status(thm)],[5])).\ncnf(7,plain,('b'|~'a'),inference(split_conjunct,[status(thm)],[6])).\ncnf(8,plain,(epred1_0),inference(split_conjunct,[status(thm)],[6])).\nfof(9, plain,(~(epred1_0)|((((~('5')|'0')&(~('0')|'5'))&(((~('4')|'3')&(~('3')|'4'))&((~('6')|('5'&'4'))&((~('5')|~('4'))|'6'))))&('a'&~('b')))),inference(fof_nnf,[status(thm)],[4])).\nfof(10, plain,(((((~('5')|'0')|~(epred1_0))&((~('0')|'5')|~(epred1_0)))&((((~('4')|'3')|~(epred1_0))&((~('3')|'4')|~(epred1_0)))&(((('5'|~('6'))|~(epred1_0))&(('4'|~('6'))|~(epred1_0)))&(((~('5')|~('4'))|'6')|~(epred1_0)))))&(('a'|~(epred1_0))&(~('b')|~(epred1_0)))),inference(distribute,[status(thm)],[9])).\ncnf(11,plain,(~epred1_0|~'b'),inference(split_conjunct,[status(thm)],[10])).\ncnf(12,plain,('a'|~epred1_0),inference(split_conjunct,[status(thm)],[10])).\ncnf(20,plain,('a'|$false),inference(rw,[status(thm)],[12,8,theory(equality)])).\ncnf(21,plain,('a'),inference(cn,[status(thm)],[20,theory(equality)])).\ncnf(22,plain,('b'|$false),inference(rw,[status(thm)],[7,21,theory(equality)])).\ncnf(23,plain,('b'),inference(cn,[status(thm)],[22,theory(equality)])).\ncnf(24,plain,($false|~epred1_0),inference(rw,[status(thm)],[11,23,theory(equality)])).\ncnf(25,plain,($false|$false),inference(rw,[status(thm)],[24,8,theory(equality)])).\ncnf(26,plain,($false),inference(cn,[status(thm)],[25,theory(equality)])).\ncnf(27,plain,($false),inference(eval_answer_literal,[status(thm)],[26,theory(answers)])).\ncnf(28,plain,($false),27,['proof']).\n# SZS output end CNFRefutation"


file2 :: String
file2 = "# Preprocessing time       : 0.000 s\n# Problem is unsatisfiable (or provable), constructing proof object\n# SZS status Unsatisfiable\n# SZS output start CNFRefutation.\nfof(1, axiom,~(((((('4'=>~($true))&(~($true)=>'4'))&((('5'=>~($true))&(~($true)=>'5'))&(('6'=>~($true))&(~($true)=>'6'))))&((('5'=>'0')&('0'=>'5'))&((('4'=>'3')&('3'=>'4'))&(('6'=>('5'&'4'))&(('5'&'4')=>'6')))))=>('6'=>'3'))),file('sample2.tptp', ax1)).\nfof(2, plain,~((((~('4')&(~('5')&~('6')))&((('5'=>'0')&('0'=>'5'))&((('4'=>'3')&('3'=>'4'))&(('6'=>('5'&'4'))&(('5'&'4')=>'6')))))=>('6'=>'3'))),inference(fof_simplification,[status(thm)],[1,theory(equality)])).\nfof(3, plain,(epred1_0<=>((~('4')&(~('5')&~('6')))&((('5'=>'0')&('0'=>'5'))&((('4'=>'3')&('3'=>'4'))&(('6'=>('5'&'4'))&(('5'&'4')=>'6')))))),introduced(definition)).\nfof(4, plain,(epred1_0=>((~('4')&(~('5')&~('6')))&((('5'=>'0')&('0'=>'5'))&((('4'=>'3')&('3'=>'4'))&(('6'=>('5'&'4'))&(('5'&'4')=>'6')))))),inference(split_equiv,[status(thm)],[3])).\nfof(5, plain,~((epred1_0=>('6'=>'3'))),inference(apply_def,[status(thm)],[2,3,theory(equality)])).\nfof(6, plain,(epred1_0&('6'&~('3'))),inference(fof_nnf,[status(thm)],[5])).\ncnf(8,plain,('6'),inference(split_conjunct,[status(thm)],[6])).\ncnf(9,plain,(epred1_0),inference(split_conjunct,[status(thm)],[6])).\nfof(10, plain,(~(epred1_0)|((~('4')&(~('5')&~('6')))&(((~('5')|'0')&(~('0')|'5'))&(((~('4')|'3')&(~('3')|'4'))&((~('6')|('5'&'4'))&((~('5')|~('4'))|'6')))))),inference(fof_nnf,[status(thm)],[4])).\nfof(11, plain,(((~('4')|~(epred1_0))&((~('5')|~(epred1_0))&(~('6')|~(epred1_0))))&((((~('5')|'0')|~(epred1_0))&((~('0')|'5')|~(epred1_0)))&((((~('4')|'3')|~(epred1_0))&((~('3')|'4')|~(epred1_0)))&(((('5'|~('6'))|~(epred1_0))&(('4'|~('6'))|~(epred1_0)))&(((~('5')|~('4'))|'6')|~(epred1_0)))))),inference(distribute,[status(thm)],[10])).\ncnf(13,plain,('4'|~epred1_0|~'6'),inference(split_conjunct,[status(thm)],[11])).\ncnf(21,plain,(~epred1_0|~'4'),inference(split_conjunct,[status(thm)],[11])).\ncnf(22,plain,('4'|$false|~epred1_0),inference(rw,[status(thm)],[13,8,theory(equality)])).\ncnf(23,plain,('4'|$false|$false),inference(rw,[status(thm)],[22,9,theory(equality)])).\ncnf(24,plain,('4'),inference(cn,[status(thm)],[23,theory(equality)])).\ncnf(34,plain,($false|~epred1_0),inference(rw,[status(thm)],[21,24,theory(equality)])).\ncnf(35,plain,($false|$false),inference(rw,[status(thm)],[34,9,theory(equality)])).\ncnf(36,plain,($false),inference(cn,[status(thm)],[35,theory(equality)])).\ncnf(37,plain,($false),inference(eval_answer_literal,[status(thm)],[36,theory(answers)])).\ncnf(38,plain,($false),37,['proof']).\n# SZS output end CNFRefutation\n"

file3 :: String
file3 = "# Preprocessing time       : 0.000 s\n# Problem is unsatisfiable (or provable), constructing proof object\n# SZS status Unsatisfiable\n# SZS output start CNFRefutation.\nfof(1, axiom,~(('0'|('1'|('2'|('3'|('4'|('5'|('6'|('7'|('8'|('9'|('10'|('11'|~(('0'|('1'|('2'|('3'|('4'|('5'|('6'|('7'|('8'|('9'|('10'|'11'))))))))))))))))))))))))),file('sample.tptp', ax1)).\nfof(2, plain,(~('0')&(~('1')&(~('2')&(~('3')&(~('4')&(~('5')&(~('6')&(~('7')&(~('8')&(~('9')&(~('10')&(~('11')&('0'|('1'|('2'|('3'|('4'|('5'|('6'|('7'|('8'|('9'|('10'|'11'))))))))))))))))))))))),inference(fof_nnf,[status(thm)],[1])).\ncnf(3,plain,('11'|'10'|'9'|'8'|'7'|'6'|'5'|'4'|'3'|'2'|'1'|'0'),inference(split_conjunct,[status(thm)],[2])).\ncnf(4,plain,(~'11'),inference(split_conjunct,[status(thm)],[2])).\ncnf(5,plain,(~'10'),inference(split_conjunct,[status(thm)],[2])).\ncnf(6,plain,(~'9'),inference(split_conjunct,[status(thm)],[2])).\ncnf(7,plain,(~'8'),inference(split_conjunct,[status(thm)],[2])).\ncnf(8,plain,(~'7'),inference(split_conjunct,[status(thm)],[2])).\ncnf(9,plain,(~'6'),inference(split_conjunct,[status(thm)],[2])).\ncnf(10,plain,(~'5'),inference(split_conjunct,[status(thm)],[2])).\ncnf(11,plain,(~'4'),inference(split_conjunct,[status(thm)],[2])).\ncnf(12,plain,(~'3'),inference(split_conjunct,[status(thm)],[2])).\ncnf(13,plain,(~'2'),inference(split_conjunct,[status(thm)],[2])).\ncnf(14,plain,(~'1'),inference(split_conjunct,[status(thm)],[2])).\ncnf(15,plain,(~'0'),inference(split_conjunct,[status(thm)],[2])).\ncnf(16,plain,('11'|'10'|'9'|'8'|'7'|'6'|'5'|'4'|'3'|'2'|'1'),inference(sr,[status(thm)],[3,15,theory(equality)])).\ncnf(17,plain,('11'|'10'|'9'|'8'|'7'|'6'|'5'|'4'|'3'|'2'),inference(sr,[status(thm)],[16,14,theory(equality)])).\ncnf(18,plain,('11'|'10'|'9'|'8'|'7'|'6'|'5'|'4'|'3'),inference(sr,[status(thm)],[17,13,theory(equality)])).\ncnf(19,plain,('11'|'10'|'9'|'8'|'7'|'6'|'5'|'4'),inference(sr,[status(thm)],[18,12,theory(equality)])).\ncnf(20,plain,('11'|'10'|'9'|'8'|'7'|'6'|'5'),inference(sr,[status(thm)],[19,11,theory(equality)])).\ncnf(21,plain,('11'|'10'|'9'|'8'|'7'|'6'),inference(sr,[status(thm)],[20,10,theory(equality)])).\ncnf(22,plain,('11'|'10'|'9'|'8'|'7'),inference(sr,[status(thm)],[21,9,theory(equality)])).\ncnf(23,plain,('11'|'10'|'9'|'8'),inference(sr,[status(thm)],[22,8,theory(equality)])).\ncnf(24,plain,('11'|'10'|'9'),inference(sr,[status(thm)],[23,7,theory(equality)])).\ncnf(25,plain,('11'|'10'),inference(sr,[status(thm)],[24,6,theory(equality)])).\ncnf(26,plain,('11'),inference(sr,[status(thm)],[25,5,theory(equality)])).\ncnf(27,plain,($false),inference(rw,[status(thm)],[4,26,theory(equality)])).\ncnf(28,plain,($false),inference(cn,[status(thm)],[27,theory(equality)])).\ncnf(29,plain,($false),inference(eval_answer_literal,[status(thm)],[28,theory(answers)])).\ncnf(30,plain,($false),29,['proof']).\n# SZS output end CNFRefutation\n"

tptplines = parse file

data PL_Formula = 
  True | False | Or PL_Formula PL_Formula |
  And PL_Formula PL_Formula | Imp PL_Formula PL_Formula |
  Var Int | Neg PL_Formula
               deriving (Show,Eq)

data PL_FormulaCode = 
  True_ | False_ | Or_ PL_FormulaCode PL_FormulaCode |
  And_ PL_FormulaCode PL_FormulaCode | Imp_ PL_FormulaCode PL_FormulaCode |
  Var_ (Either String Int) | Neg_ PL_FormulaCode
  deriving (Show,Eq)
data ERule f =
  NNF | Simplify | SplitConj | CN | Axiom | UnSat | Distribute |
  Apply f f | RW f | Fresh Int f | SR f
  deriving (Show,Eq)
data ERuleCode =
  NNF_ Int | Simplify_ Int  | SplitConj_ Int | CN_ Int | Axiom_ | UnSat_ Int | Distribute_ Int |
  Apply_ Int Int | RW_ Int Int | Void_ Int | SR_ Int Int
  deriving (Show)

data Proves f =
--  (:-) [f] f
  (:-) {gamma :: [f] , phi :: f}
  deriving (Show,Eq)

data ProofTree r f = 
  ProofNode {rule :: r , conc :: f , seq :: [ ProofTree r f ] }
  deriving (Show,Eq)

binop2formula :: BinOp -> PL_FormulaCode -> PL_FormulaCode -> PL_FormulaCode
binop2formula (:<=>:) a b = And_ (Imp_ a b) (Imp_ b a)
binop2formula (:=>:) a b = Imp_ a b
binop2formula (:<=:) a b = Imp_ b a
binop2formula (:&:) a b = And_ a b
binop2formula (:|:) a b = Or_ a b
-- possibly these make inconsistencies
binop2formula (:~&:) a b = Neg_ (And_ a b)
binop2formula (:~|:) a b = Neg_ (Or_ a b)
binop2formula (:<~>:) a b = And_ (Or_ a b) (Or_ (Neg_ a) (Neg_ b))

readatom :: String -> Either String Int
readatom s = case ((reads :: ReadS Int) s) of 
  [(n,[])] -> Right n 
  _ -> Left s


atom2formula :: AtomicWord -> PL_FormulaCode
atom2formula (AtomicWord atom) | atom == "$true" = Main.True_
                               | atom == "$false" = Main.False_
                               | otherwise = Main.Var_ $ readatom atom

formula02formula :: Formula0 (T Identity) (F Identity) -> PL_FormulaCode
formula02formula (BinOp a op b) = binop2formula op (formula2formula a) (formula2formula b)
formula02formula (InfixPred t1 ip t2) = undefined -- not used
formula02formula (PredApp atom []) = atom2formula atom -- all variables and constants are here
formula02formula (PredApp atom ts) = undefined -- predicates not used
formula02formula (Quant q vs f) = undefined -- should not happen, only propositional formulae
formula02formula ((:~:) a) = Neg_ (formula2formula a)


formula2formula :: F Identity -> PL_FormulaCode
formula2formula = formula02formula . runIdentity . runF


input2formula :: TPTP_Input -> PL_FormulaCode
input2formula = formula2formula . formula
{-
  NNF | Simplify | SplitConj | CN | Axiom | UnSat | Distribute |
  Apply f f | RW f | Fresh Int f
-}

tonum :: GTerm -> Int
tonum (GTerm (GNumber n)) = floor n
tonum _ = undefined

inference2rule :: [GTerm] -> ERuleCode
inference2rule [GTerm (GWord (AtomicWord a)) , _ , GList b] | a == "fof_nnf" = NNF_ (tonum (head b))
                                                      | a == "fof_simplification" = Simplify_ (tonum (head b))
                                                      | a == "split_equiv" = SplitConj_ (tonum (head b))
                                                      | a == "split_conjunct" = SplitConj_ (tonum (head b))
                                                      | a == "cn" = CN_ (tonum (head b))
                                                      | a == "distribute" = Distribute_ (tonum (head b))
                                                      | a == "apply_def" = Apply_ (tonum (head b)) (tonum (head (tail b)))
                                                      | a == "rw" = RW_ (tonum (head b)) (tonum (head (tail b)))
                                                      | a == "eval_answer_literal" = Void_ (tonum (head b))
                                                      | a == "sr" = SR_ (tonum (head b)) (tonum (head (tail b)))
inference2rule _ = undefined

annotation2rule :: Annotations -> ERuleCode
annotation2rule NoAnnotations = undefined
annotation2rule (Annotations (GTerm (GApp (AtomicWord n) args)) NoUsefulInfo) | n == "introduced" = Axiom_
                                                                              | n == "inference" = inference2rule args
                                                                              | n == "file" = Axiom_
annotation2rule (Annotations (GTerm (GNumber n)) (UsefulInfo [(GTerm (GWord (AtomicWord m)))])) | m == "proof" = UnSat_ (floor n)
annotation2rule (Annotations gt _) = undefined


input2rule :: TPTP_Input -> ERuleCode
input2rule = annotation2rule . annotations

input2id :: TPTP_Input -> Int
input2id = (\ (AtomicWord x) -> read x) . name

filt_AFormula :: TPTP_Input -> Bool
filt_AFormula (AFormula _ _ _ _) = Prelude.True
filt_AFormula _ = Prelude.False

filt_Comment :: TPTP_Input -> Bool
filt_Comment (Comment _) = Prelude.True
filt_Comment _ = Prelude.False

type Record = (Int , (PL_FormulaCode,ERuleCode))
type Record2 = (Int , (PL_Formula,ERuleCode))

tptpline2 = filter filt_AFormula tptplines

input2record x = (input2id x , (input2formula x , input2rule x))

records :: [Record]
records = map input2record tptpline2

next :: [Int] -> Int
next xs = f xs 0
  where 
    f :: [Int] -> Int -> Int
    f xs n | n `elem` xs = f xs (n + 1)
           | otherwise = n
                         
getvars :: PL_FormulaCode -> [Int]
getvars True_ = []
getvars False_ = []
getvars (Or_ a b) = getvars a ++ getvars b
getvars (And_ a b) = getvars a ++ getvars b
getvars (Imp_ a b) = getvars a ++ getvars b
getvars (Var_ x) = either (\ _ -> []) (:[]) x
getvars (Neg_ a) = getvars a

getvars' :: [Record] -> [Int]
getvars' = foldr (\ (_ , (formula , rule)) b -> getvars formula ++ b) []


getstrings :: PL_FormulaCode -> [String]
getstrings True_ = []
getstrings False_ = []
getstrings (Or_ a b) = getstrings a ++ getstrings b
getstrings (And_ a b) = getstrings a ++ getstrings b
getstrings (Imp_ a b) = getstrings a ++ getstrings b
getstrings (Var_ x) = either (:[]) (\ _ -> []) x
getstrings (Neg_ a) = getstrings a

getstrings' :: [Record] -> [String]
getstrings' = foldr (\ (_ , (formula , rule)) b -> getstrings formula ++ b) []

buildvarmap :: [Int] -> [String] -> [(String , Int)]
buildvarmap ids [] = []
buildvarmap ids (s : strs) | s `elem` strs = buildvarmap ids strs
                           | otherwise     = let n = Main.next ids
                                             in (s , n) : buildvarmap (n : ids) strs


buildvarmap' :: [Int] -> [String] -> Map.Map String Int
buildvarmap' ids strs = Map.fromList $ buildvarmap ids strs

toformula :: Map.Map String Int -> PL_FormulaCode -> PL_Formula
toformula env True_ = Main.True
toformula env False_ = Main.False
toformula env (Or_ a b) = Or (toformula env a) (toformula env b)
toformula env (And_ a b) = And (toformula env a) (toformula env b)
toformula env (Imp_ a b) = Imp (toformula env a) (toformula env b)
-- lookup should never fail assuming the environment has been correctly 
-- constructed, i.e. total w.r.t. strings occuring in the formula (fromJust?)
toformula env (Var_ x) = Main.Var $ either (\ s ->  maybe (-1) id $ Map.lookup s env) (id) x
toformula env (Neg_ a) = Neg $ toformula env a

toformula' :: [(String,Int)] -> PL_FormulaCode -> PL_Formula
toformula' env True_ = Main.True
toformula' env False_ = Main.False
toformula' env (Or_ a b) = Or (toformula' env a) (toformula' env b)
toformula' env (And_ a b) = And (toformula' env a) (toformula' env b)
toformula' env (Imp_ a b) = Imp (toformula' env a) (toformula' env b)
-- lookup should never fail assuming the environment has been correctly 
-- constructed, i.e. total w.r.t. strings occuring in the formula (fromJust?)
toformula' env (Var_ x) = Main.Var $ either (\ s ->  maybe (-1) id $ lookup s env) (id) x
toformula' env (Neg_ a) = Neg $ toformula' env a

record2 :: Map.Map String Int -> Record -> Record2
record2 env (i , (f , r)) = (i , (toformula env f , r))

records2 :: [Record] -> [Record2]
records2 r = map (record2 (buildvarmap' (getvars' r) (getstrings' r))) r


-- to rebuild the tree, take the record with maximal id and reconstruct using the rule
-- indices.

getroot :: [(Int,b)] -> Maybe (Int,b) --(PL-Formula,ERuleCode)
getroot xs = foldr (\ a b -> if (fst a > maybe (-1) fst b) then Just a else b) Nothing  xs

splitand :: PL_Formula -> PL_Formula
splitand (And f1 f2) = f1
splitand x = x

splitand' :: PL_Formula -> PL_Formula
splitand' (And f1 f2) = f2
splitand' x = x

splitimp :: PL_Formula -> PL_Formula
splitimp (Imp f1 f2) = f1
splitimp x = x

splitimp' :: PL_Formula -> PL_Formula
splitimp' (Imp f1 f2) = f2
splitimp' x = x

subformula :: PL_Formula -> PL_Formula -> Bool
subformula x y | x == y = Prelude.True
subformula x Main.True = Prelude.False
subformula x Main.False = Prelude.False
subformula x (Or a b) = subformula x a || subformula x b
subformula x (And a b) = subformula x a || subformula x b
subformula x (Imp a b) =  subformula x a || subformula x b
subformula x (Main.Var n) = Prelude.False
subformula x (Neg a) = subformula x a

unnegate :: PL_Formula -> PL_Formula
unnegate (Neg a) = a
unnegate (Imp a Main.False) = a
unnegate a = a

{-
buildtree :: (PL_Formula,ERuleCode) -> [Record2] -> ProofTree (ERule PL_Formula) (Proves PL_Formula)
buildtree (f , NNF_ n) m = ProofNode NNF f [ buildtree (fromJust $ lookup n m) m ]
buildtree (f , Simplify_ n) m = ProofNode Simplify f [ buildtree (fromJust $ lookup n m) m ]
buildtree (f , SplitConj_ n) m = ProofNode SplitConj f [ buildtree (fromJust $ lookup n m) m ]
buildtree (f , CN_ n) m = ProofNode CN f [ buildtree (fromJust $ lookup n m) m ]
buildtree (f , Axiom_) m = ProofNode Axiom f []
buildtree (f , UnSat_ n) m = ProofNode UnSat f [ buildtree (fromJust $ lookup n m) m ]
buildtree (f , Distribute_ n) m = ProofNode Distribute f [ buildtree (fromJust $ lookup n m) m ]
buildtree (f , Apply_ n1 n2) m = let r2 = buildtree (fromJust $ lookup n2 m) m
                                     g = conc r2
                                 in ProofNode (Apply (splitimp $ splitand g) (splitimp' $ splitand g)) f [ buildtree (fromJust $ lookup n1 m) m , r2 ]
buildtree (f , RW_ n1 n2) m = let r1 = buildtree (fromJust $ lookup n1 m) m
                                  r2 = buildtree (fromJust $ lookup n2 m) m
                                  f' = if (Neg (conc r2) `subformula` conc r1) then conc r2
                                       else unnegate $ conc r2
                              in ProofNode (RW f') f [ r1 , r2 ]
buildtree (f , Void_ n) m = buildtree (fromJust $ lookup n m) m
-}
  
{-
-- outdated, does not handle SR_
buildtree :: (PL_Formula,ERuleCode) -> [Record2] -> ProofTree (ERule PL_Formula) (Proves PL_Formula)
buildtree (f , NNF_ n) m = let r = buildtree (fromJust $ lookup n m) m
                           in ProofNode NNF ((gamma $ conc r) :- f) [ r ]
buildtree (f , Simplify_ n) m = let r = buildtree (fromJust $ lookup n m) m
                                in ProofNode Simplify ((gamma $ conc r) :- f) [ r ]
buildtree (f , SplitConj_ n) m = let r = buildtree (fromJust $ lookup n m) m
                                 in ProofNode SplitConj ((gamma $ conc r) :- f) [ r ]
buildtree (f , CN_ n) m = let r = buildtree (fromJust $ lookup n m) m
                          in ProofNode CN ((gamma $ conc r) :- f) [ r ]
buildtree (f , Axiom_) m = ProofNode Axiom ([f] :- f) []
buildtree (f , UnSat_ n) m = let f1 = phi $ conc $ buildtree (fromJust $ lookup 1 m) m -- axiom from file, should always be negated
                                 r = buildtree (fromJust $ lookup n m) m
--             might need to change equality here to equivalence       \/\/
                             in ProofNode UnSat (filter (\ a -> not $ f1 == a) (gamma $ conc r) :- (unnegate f1)) [ r ]
buildtree (f , Distribute_ n) m = let r = buildtree (fromJust $ lookup n m) m
                                  in ProofNode Distribute ((gamma $ conc r) :- f) [ r ]
buildtree (f , Apply_ n1 n2) m = let r1 = buildtree (fromJust $ lookup n1 m) m
                                     r2 = buildtree (fromJust $ lookup n2 m) m
                                     g = phi $ conc r2
                                 in ProofNode (Apply (splitimp $ splitand g) (splitimp' $ splitand g)) (List.nub ((gamma $ conc r1) ++ (gamma $ conc r2)) :- f) [ r1 , r2 ]
buildtree (f , RW_ n1 n2) m = let r1 = buildtree (fromJust $ lookup n1 m) m
                                  r2 = buildtree (fromJust $ lookup n2 m) m
                                  f' = if (Neg (phi $ conc r2) `subformula` (phi $ conc r1)) then phi $ conc r2
                                       else unnegate $ phi $ conc r2
                              in ProofNode (RW f') (List.nub ((gamma $ conc r1) ++ (gamma $ conc r2)) :- f) [ r1 , r2 ]
buildtree (f , Void_ n) m = buildtree (fromJust $ lookup n m) m
-}


--- ######

-- map from strings to variable indices, root node, records => tree
buildtree' :: [(String,Int)] -> (PL_FormulaCode,ERuleCode) -> [Record] -> ProofTree (ERule PL_Formula) (Proves PL_Formula)
buildtree' env (f , NNF_ n) m = let r = buildtree' env (fromJust $ lookup n m) m
                                in ProofNode NNF ((gamma $ conc r) :- toformula' env f) [ r ]
buildtree' env (f , Simplify_ n) m = let r = buildtree' env (fromJust $ lookup n m) m
                                     in ProofNode Simplify ((gamma $ conc r) :- toformula' env f) [ r ]
buildtree' env (f , SplitConj_ n) m = let r = buildtree' env (fromJust $ lookup n m) m
                                      in ProofNode SplitConj ((gamma $ conc r) :- toformula' env f) [ r ]
buildtree' env (f , CN_ n) m = let r = buildtree' env (fromJust $ lookup n m) m
                               in ProofNode CN ((gamma $ conc r) :- toformula' env f) [ r ]
buildtree' env (f , Axiom_) m = ProofNode Axiom ([toformula' env f] :- toformula' env f) []
buildtree' env (f , UnSat_ n) m = let f1 = phi $ conc $ buildtree' env (fromJust $ lookup 1 m) m -- axiom from file, should always be negated
                                      r = buildtree' env (fromJust $ lookup n m) m
--             might need to change equality here to equivalence       \/\/
                                  in ProofNode UnSat (filter (\ a -> not $ f1 == a) (gamma $ conc r) :- (unnegate f1)) [ r ]
buildtree' env (f , Distribute_ n) m = let r = buildtree' env (fromJust $ lookup n m) m
                                       in ProofNode Distribute ((gamma $ conc r) :- toformula' env f) [ r ]
buildtree' env (f , Apply_ n1 n2) m = let r1 = buildtree' env (fromJust $ lookup n1 m) m
                                          r2 = buildtree' env (fromJust $ lookup n2 m) m
                                          g = phi $ conc r2
                                      in ProofNode (Apply (splitimp $ splitand g) (splitimp' $ splitand g)) (List.nub ((gamma $ conc r1) ++ (gamma $ conc r2)) :- toformula' env f) [ r1 , r2 ]
buildtree' env (f , RW_ n1 n2) m = let r1 = buildtree' env (fromJust $ lookup n1 m) m
                                       r2 = buildtree' env (fromJust $ lookup n2 m) m
                                       f' = if (Neg (phi $ conc r2) `subformula` (phi $ conc r1)) then phi $ conc r2
                                            else unnegate $ phi $ conc r2
                                   in ProofNode (RW f') (List.nub ((gamma $ conc r1) ++ (gamma $ conc r2)) :- toformula' env f) [ r1 , r2 ]
buildtree' env (f , Void_ n) m = buildtree' env (fromJust $ lookup n m) m
buildtree' env (f , SR_ n1 n2) m = let r1 = buildtree' env (fromJust $ lookup n1 m) m
                                       r2 = buildtree' env (fromJust $ lookup n2 m) m
                                       f' = if (Neg (phi $ conc r2) `subformula` (phi $ conc r1)) then phi $ conc r2
                                            else unnegate $ phi $ conc r2
                                   in ProofNode (SR f') (List.nub ((gamma $ conc r1) ++ (gamma $ conc r2)) :- toformula' env f) [ r1 , r2 ]

isEquiv :: PL_Formula -> Bool
isEquiv (And (Imp (Main.Var a) b) (Imp c (Main.Var d))) = a == d && b == c
isEquiv _ = Prelude.False

dischargetree :: ProofTree (ERule PL_Formula) (Proves PL_Formula) -> ProofTree (ERule PL_Formula) (Proves PL_Formula)
dischargetree t | (gamma $ conc t) == [] = t
dischargetree t | isEquiv $ head $ gamma $ conc t = dischargetree $ ProofNode (Fresh ((\ (Main.Var n) -> n) $ splitimp $ splitand $ head $ gamma $ conc t) (splitimp' $ splitand $ head $ gamma $ conc t)) ((tail $ gamma $ conc t) :- (phi $ conc t)) [t]



step1 :: [TPTP_Input] -> [Record]
step1 = (map input2record) . (filter filt_AFormula)

run :: String -> Maybe (ProofTree (ERule PL_Formula) (Proves PL_Formula))
run s = let tptplines = parse s
            x = step1 tptplines
            isunsat = (Comment "# SZS status Unsatisfiable") `elem` filter filt_Comment tptplines
        in if isunsat 
           then Just $ dischargetree $ buildtree' (buildvarmap (getvars' x) (getstrings' x)) (snd $ fromJust $ getroot x) x 
           else Nothing


-}